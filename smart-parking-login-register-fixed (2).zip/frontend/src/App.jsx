import { HashRouter, Routes, Route, NavLink, Link, useLocation } from 'react-router-dom';
import Home from './pages/Home.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import UserDashboard from './pages/UserDashboard.jsx';
import Booking from './pages/Booking.jsx';
import Contact from './pages/Contact.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';

function Layout() {
  const location = useLocation();
  const isAuthPage = ['/login', '/register'].includes(location.pathname);

  return (
    <>
      {!isAuthPage && (
        <nav className="navbar">
          <NavLink to="/" className="logo">Smart Parking</NavLink>
          <div className="nav-links">
            <NavLink to="/">Home</NavLink>
            <NavLink to="/booking">Book Slot</NavLink>
            <NavLink to="/user">User Dashboard</NavLink>
            <NavLink to="/admin">Admin Dashboard</NavLink>
            <NavLink to="/contact">Contact</NavLink>
            <NavLink to="/login" className="login-pill">Login</NavLink>
            <NavLink to="/register" className="register-pill">Register</NavLink>
          </div>
        </nav>
      )}

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/booking" element={<Booking />} />
        <Route path="/user" element={<UserDashboard />} />
        <Route path="/admin" element={<AdminDashboard />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="*" element={<main className="container"><div className="card"><h1>404 - Page Not Found</h1><p>This page does not exist.</p><Link className="btn" to="/">Go Home</Link></div></main>} />
      </Routes>

      {!isAuthPage && (
        <footer className="footer">
          <b>Smart Parking System</b><br />
          Demo full-stack project with React, Node.js, Express, MongoDB and working database APIs.
        </footer>
      )}
    </>
  );
}

export default function App() {
  return (
    <HashRouter>
      <Layout />
    </HashRouter>
  );
}
