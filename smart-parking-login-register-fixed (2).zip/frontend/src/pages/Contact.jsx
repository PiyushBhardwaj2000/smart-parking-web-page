import { useState } from 'react';
import api from '../api';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  function change(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function submit(e) {
    e.preventDefault();
    setMessage('');
    setError('');
    if (!form.name || !form.email || !form.message) {
      setError('Please fill all fields.');
      return;
    }
    try {
      await api.post('/contact', form);
      setMessage('Your message has been saved in database.');
      setForm({ name: '', email: '', message: '' });
    } catch (err) {
      setError(err.response?.data?.message || 'Message save failed');
    }
  }

  return (
    <main className="container">
      <h1 className="section-title">Contact Us</h1>
      {message && <div className="alert">{message}</div>}
      {error && <div className="alert error">{error}</div>}
      <div className="card">
        <form className="form" onSubmit={submit}>
          <div className="form-grid">
            <div><label>Name</label><input name="name" value={form.name} onChange={change} placeholder="Your name" /></div>
            <div><label>Email</label><input name="email" value={form.email} onChange={change} placeholder="your@email.com" /></div>
          </div>
          <div><label>Message</label><textarea name="message" value={form.message} onChange={change} placeholder="Write your message" /></div>
          <button className="btn" type="submit">Send Message</button>
        </form>
      </div>
    </main>
  );
}
