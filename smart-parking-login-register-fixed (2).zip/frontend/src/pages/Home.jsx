import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <main className="container">
      <section className="hero">
        <div>
          <h1>Smart Parking Booking & Management System</h1>
          <p>
            Real-time parking slot availability, booking management, dashboard reports and MongoDB based persistent storage.
          </p>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginTop: 22 }}>
            <Link className="btn" to="/booking">Book Parking Slot</Link>
            <Link className="btn secondary" to="/admin">Open Admin Panel</Link>
          </div>
        </div>
        <div className="hero-card">
          <h2>Project Modules</h2>
          <p>All main pages are connected with backend APIs.</p>
          <div className="grid">
            <div className="stat">Slot Management<b>CRUD</b></div>
            <div className="stat">Booking System<b>Live</b></div>
            <div className="stat">MongoDB<b>DB</b></div>
            <div className="stat">Reports<b>Auto</b></div>
          </div>
        </div>
      </section>
    </main>
  );
}
