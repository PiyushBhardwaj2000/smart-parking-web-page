import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import api from '../api';

const initial = { role: 'User', fullName: '', email: '', phone: '', password: '', otp: '' };

export default function Register() {
  const [form, setForm] = useState(initial);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  function change(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function generateOtp() {
    setError('');
    if (!form.email) {
      setError('OTP generate karne se pehle Gmail/Email enter karein.');
      return;
    }
    const otp = String(Math.floor(100000 + Math.random() * 900000));
    setGeneratedOtp(otp);
    setMessage(`Demo OTP generated: ${otp}. Isko OTP box me enter karein.`);
  }

  async function submit(e) {
    e.preventDefault();
    setMessage('');
    setError('');
    if (!form.role || !form.fullName || !form.email || !form.phone || !form.password || !form.otp) {
      setError('Koi bhi field blank nahi honi chahiye.');
      return;
    }
    if (form.password.length < 6) {
      setError('Password minimum 6 characters ka hona chahiye.');
      return;
    }
    if (!generatedOtp || form.otp !== generatedOtp) {
      setError('OTP wrong hai. Pehle Generate OTP click karein aur same OTP enter karein.');
      return;
    }
    try {
      const res = await api.post('/auth/register', form);
      localStorage.setItem('smartParkingUser', JSON.stringify(res.data.user));
      setMessage('Registration successful. Login page open ho raha hai...');
      setTimeout(() => navigate('/login'), 700);
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed. Backend check karein.');
    }
  }

  async function googleRegister() {
    setError('');
    setMessage('');
    const name = prompt('Google demo ke liye apna name enter karein:');
    const email = prompt('Google demo ke liye Gmail enter karein:');
    if (!name || !email) {
      setError('Google signup ke liye name aur Gmail required hai.');
      return;
    }
    try {
      const res = await api.post('/auth/google', { fullName: name, email, role: form.role });
      localStorage.setItem('smartParkingUser', JSON.stringify(res.data.user));
      navigate('/user');
    } catch (err) {
      setError(err.response?.data?.message || 'Google signup failed.');
    }
  }

  return (
    <main className="auth-page register-bg">
      <section className="auth-shell register-shell">
        <div className="auth-brand compact-brand">
          <div className="brand-mark">P</div>
          <span>Smart Parking</span>
        </div>
        <div className="auth-card register-card">
          <h1>Create Account</h1>
          {message && <div className="alert">{message}</div>}
          {error && <div className="alert error">{error}</div>}
          <form onSubmit={submit} className="auth-form">
            <label>Select Role</label>
            <select name="role" value={form.role} onChange={change}>
              <option>User</option>
              <option>Admin</option>
              <option>Staff</option>
            </select>

            <label>Full Name</label>
            <input name="fullName" value={form.fullName} onChange={change} placeholder="Full Name" />

            <label>Email</label>
            <input name="email" type="email" value={form.email} onChange={change} placeholder="email@example.com" />

            <label>Phone</label>
            <input name="phone" value={form.phone} onChange={change} placeholder="Phone Number" />

            <label>Password</label>
            <input name="password" type="password" value={form.password} onChange={change} placeholder="Create Password" />

            <div className="otp-row">
              <button type="button" className="outline-btn" onClick={generateOtp}>✉ Generate OTP to Gmail</button>
              <input name="otp" value={form.otp} onChange={change} placeholder="Enter 6 digit OTP" />
            </div>

            <button className="auth-primary" type="submit">Register Now</button>
            <button className="google-btn" type="button" onClick={googleRegister}><span className="google-g">G</span> Sign up with Google</button>
          </form>
          <p className="auth-link-text">Already have an account? <Link to="/login">Login</Link></p>
        </div>
      </section>
    </main>
  );
}
