import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import api from '../api';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '', remember: false });
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  function change(e) {
    const value = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setForm({ ...form, [e.target.name]: value });
  }

  async function submit(e) {
    e.preventDefault();
    setError('');
    setMessage('');
    if (!form.email || !form.password) {
      setError('Email aur password blank nahi hona chahiye.');
      return;
    }
    try {
      const res = await api.post('/auth/login', form);
      localStorage.setItem('smartParkingUser', JSON.stringify(res.data.user));
      setMessage('Login successful. Dashboard open ho raha hai...');
      setTimeout(() => navigate(res.data.user.role === 'Admin' ? '/admin' : '/user'), 500);
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Email/password check karein.');
    }
  }

  async function googleLogin() {
    setError('');
    const email = prompt('Google demo login ke liye Gmail enter karein:');
    if (!email) {
      setError('Gmail required hai.');
      return;
    }
    try {
      const res = await api.post('/auth/google', { fullName: email.split('@')[0], email, role: 'User' });
      localStorage.setItem('smartParkingUser', JSON.stringify(res.data.user));
      navigate('/user');
    } catch (err) {
      setError(err.response?.data?.message || 'Google login failed.');
    }
  }

  function forgotPassword() {
    if (!form.email) {
      setError('Forgot password ke liye pehle email enter karein.');
      return;
    }
    setMessage('Demo reset link generated. Real Gmail email service add karne par link mail ho jayega.');
  }

  return (
    <main className="auth-page login-bg">
      <div className="login-brand"><div className="brand-mark">P</div><span>Smart Parking</span></div>
      <section className="login-card">
        <p className="muted center">Please enter your details</p>
        <h1 className="center">Welcome back</h1>
        {message && <div className="alert">{message}</div>}
        {error && <div className="alert error">{error}</div>}
        <form onSubmit={submit} className="login-form">
          <input name="email" type="email" value={form.email} onChange={change} placeholder="Email address" />
          <input name="password" type="password" value={form.password} onChange={change} placeholder="Password" />
          <div className="login-options">
            <label className="check-label"><input type="checkbox" name="remember" checked={form.remember} onChange={change} /> Remember for 30 days</label>
            <button type="button" className="link-btn" onClick={forgotPassword}>Forgot password</button>
          </div>
          <button className="auth-primary" type="submit">Sign in</button>
          <button className="google-btn" type="button" onClick={googleLogin}><span className="google-g">G</span> Sign in with Google</button>
        </form>
        <p className="auth-link-text">Don&apos;t have an account? <Link to="/register">Sign up</Link></p>
        <p className="demo-note">Demo admin: admin@parking.com / admin123</p>
      </section>
    </main>
  );
}
