import { useEffect, useState } from 'react';
import api from '../api';

const emptySlot = { slotNumber: '', floor: '', vehicleType: 'Car', hourlyRate: 40, status: 'Available' };

export default function AdminDashboard() {
  const [dashboard, setDashboard] = useState(null);
  const [slots, setSlots] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [slotForm, setSlotForm] = useState(emptySlot);
  const [editId, setEditId] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  async function loadData() {
    const [d, s, b] = await Promise.all([api.get('/dashboard'), api.get('/slots'), api.get('/bookings')]);
    setDashboard(d.data);
    setSlots(s.data);
    setBookings(b.data);
  }

  useEffect(() => {
    loadData().catch(() => setError('Backend/MongoDB connect nahi ho raha. Backend terminal check karein.'));
  }, []);

  function change(e) {
    setSlotForm({ ...slotForm, [e.target.name]: e.target.value });
  }

  async function saveSlot(e) {
    e.preventDefault();
    setMessage('');
    setError('');
    if (!slotForm.slotNumber || !slotForm.floor || !slotForm.vehicleType || !slotForm.hourlyRate || !slotForm.status) {
      setError('Please fill all slot fields.');
      return;
    }
    try {
      if (editId) await api.put(`/slots/${editId}`, slotForm);
      else await api.post('/slots', slotForm);
      setMessage(editId ? 'Slot updated successfully' : 'Slot added successfully');
      setSlotForm(emptySlot);
      setEditId(null);
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Slot save failed');
    }
  }

  function editSlot(slot) {
    setEditId(slot._id);
    setSlotForm({ slotNumber: slot.slotNumber, floor: slot.floor, vehicleType: slot.vehicleType, hourlyRate: slot.hourlyRate, status: slot.status });
  }

  async function deleteSlot(id) {
    if (!confirm('Delete this slot?')) return;
    try {
      await api.delete(`/slots/${id}`);
      setMessage('Slot deleted');
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Delete failed');
    }
  }

  async function completeBooking(id) {
    try {
      await api.patch(`/bookings/${id}/complete`);
      setMessage('Booking completed and slot available again');
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Update failed');
    }
  }

  async function deleteBooking(id) {
    if (!confirm('Delete this booking?')) return;
    try {
      await api.delete(`/bookings/${id}`);
      setMessage('Booking deleted');
      loadData();
    } catch (err) {
      setError(err.response?.data?.message || 'Delete failed');
    }
  }

  return (
    <main className="container">
      <h1 className="section-title">Admin Dashboard</h1>
      {message && <div className="alert">{message}</div>}
      {error && <div className="alert error">{error}</div>}

      <div className="grid">
        <div className="stat">Total Slots<b>{dashboard?.totalSlots ?? 0}</b></div>
        <div className="stat">Available<b>{dashboard?.availableSlots ?? 0}</b></div>
        <div className="stat">Booked<b>{dashboard?.bookedSlots ?? 0}</b></div>
        <div className="stat">Revenue<b>₹{dashboard?.revenue ?? 0}</b></div>
      </div>

      <section className="card" style={{ marginTop: 22 }}>
        <h2>{editId ? 'Edit Parking Slot' : 'Add New Parking Slot'}</h2>
        <form className="form" onSubmit={saveSlot}>
          <div className="form-grid">
            <div><label>Slot Number</label><input name="slotNumber" value={slotForm.slotNumber} onChange={change} placeholder="A-03" /></div>
            <div><label>Floor</label><input name="floor" value={slotForm.floor} onChange={change} placeholder="Ground Floor" /></div>
            <div><label>Vehicle Type</label><select name="vehicleType" value={slotForm.vehicleType} onChange={change}><option>Car</option><option>Bike</option><option>EV</option></select></div>
            <div><label>Hourly Rate</label><input name="hourlyRate" type="number" value={slotForm.hourlyRate} onChange={change} /></div>
            <div><label>Status</label><select name="status" value={slotForm.status} onChange={change}><option>Available</option><option>Booked</option><option>Maintenance</option></select></div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn" type="submit">{editId ? 'Update Slot' : 'Add Slot'}</button>
            {editId && <button className="btn secondary" type="button" onClick={() => { setEditId(null); setSlotForm(emptySlot); }}>Cancel Edit</button>}
          </div>
        </form>
      </section>

      <h2 className="section-title">Parking Slots</h2>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Slot</th><th>Floor</th><th>Vehicle</th><th>Rate</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>{slots.map((slot) => <tr key={slot._id}><td>{slot.slotNumber}</td><td>{slot.floor}</td><td>{slot.vehicleType}</td><td>₹{slot.hourlyRate}/hr</td><td><span className={`badge ${slot.status}`}>{slot.status}</span></td><td><button className="btn small" onClick={() => editSlot(slot)}>Edit</button> <button className="btn danger small" onClick={() => deleteSlot(slot._id)}>Delete</button></td></tr>)}</tbody>
        </table>
      </div>

      <h2 className="section-title">All Bookings</h2>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Phone</th><th>Vehicle</th><th>Slot</th><th>Hours</th><th>Amount</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>{bookings.map((b) => <tr key={b._id}><td>{b.name}</td><td>{b.phone}</td><td>{b.vehicleNumber} ({b.vehicleType})</td><td>{b.slot?.slotNumber || 'Deleted slot'}</td><td>{b.hours}</td><td>₹{b.amount}</td><td><span className={`badge ${b.status}`}>{b.status}</span></td><td>{b.status === 'Active' && <button className="btn small" onClick={() => completeBooking(b._id)}>Complete</button>} <button className="btn danger small" onClick={() => deleteBooking(b._id)}>Delete</button></td></tr>)}</tbody>
        </table>
      </div>
    </main>
  );
}
