SMART PARKING FULLSTACK - RUN GUIDE

Important: frontend/index.html ko direct double-click se open mat karein. React/Vite project ko terminal se run karna hota hai.

1) MongoDB start karein
   - MongoDB Compass open karke mongodb://127.0.0.1:27017 connect karein
   - Ya terminal me: mongod

2) Backend run karein
   cd backend
   npm install
   npm start

   Browser check:
   http://localhost:5000
   Output me Smart Parking Backend Running dikhna chahiye.

3) Frontend run karein - new terminal me
   cd frontend
   npm install
   npm run dev

   Browser open:
   http://localhost:5173

4) Agar blank page aaye:
   - Browser me Ctrl + Shift + R press karein
   - URL exactly http://localhost:5173/#/ hona chahiye
   - Backend terminal band na ho
   - MongoDB running ho
   - Console me error check karein: browser me F12 > Console

This fixed version uses HashRouter, so page reload/direct route open karne par blank page nahi aana chahiye.
