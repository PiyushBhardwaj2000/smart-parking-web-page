import { useEffect, useState } from 'react';
import api from '../api';

export default function UserDashboard() {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/bookings')
      .then((res) => setBookings(res.data))
      .catch(() => setError('Bookings load nahi ho rahi. Backend aur MongoDB start karein.'));
  }, []);

  return (
    <main className="container">
      <h1 className="section-title">User Dashboard</h1>
      {error && <div className="alert error">{error}</div>}
      <div className="grid">
        <div className="stat">My Total Bookings<b>{bookings.length}</b></div>
        <div className="stat">Active Bookings<b>{bookings.filter((b) => b.status === 'Active').length}</b></div>
        <div className="stat">Completed<b>{bookings.filter((b) => b.status === 'Completed').length}</b></div>
      </div>
      <h2 className="section-title">Recent Bookings</h2>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Name</th><th>Vehicle</th><th>Slot</th><th>Hours</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>
            {bookings.map((b) => <tr key={b._id}><td>{b.name}</td><td>{b.vehicleNumber}</td><td>{b.slot?.slotNumber || 'N/A'}</td><td>{b.hours}</td><td>₹{b.amount}</td><td><span className={`badge ${b.status}`}>{b.status}</span></td></tr>)}
            {bookings.length === 0 && <tr><td colSpan="6">No booking found. Book Slot page se new booking karein.</td></tr>}
          </tbody>
        </table>
      </div>
    </main>
  );
}
