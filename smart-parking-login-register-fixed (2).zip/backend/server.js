const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/smartparking';

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:5173' }));
app.use(express.json());


const userSchema = new mongoose.Schema(
  {
    role: { type: String, enum: ['User', 'Admin', 'Staff'], default: 'User' },
    fullName: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    phone: { type: String, trim: true, default: '' },
    password: { type: String, required: true },
    provider: { type: String, enum: ['local', 'google-demo'], default: 'local' },
  },
  { timestamps: true }
);

const slotSchema = new mongoose.Schema(
  {
    slotNumber: { type: String, required: true, unique: true, trim: true },
    floor: { type: String, required: true, trim: true },
    vehicleType: { type: String, enum: ['Car', 'Bike', 'EV'], default: 'Car' },
    hourlyRate: { type: Number, required: true, min: 0 },
    status: { type: String, enum: ['Available', 'Booked', 'Maintenance'], default: 'Available' },
  },
  { timestamps: true }
);

const bookingSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    phone: { type: String, required: true, trim: true },
    vehicleNumber: { type: String, required: true, uppercase: true, trim: true },
    vehicleType: { type: String, enum: ['Car', 'Bike', 'EV'], required: true },
    slot: { type: mongoose.Schema.Types.ObjectId, ref: 'Slot', required: true },
    hours: { type: Number, required: true, min: 1 },
    amount: { type: Number, required: true, min: 0 },
    status: { type: String, enum: ['Active', 'Completed', 'Cancelled'], default: 'Active' },
  },
  { timestamps: true }
);

const contactSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, trim: true },
    message: { type: String, required: true, trim: true },
  },
  { timestamps: true }
);

const User = mongoose.model('User', userSchema);
const Slot = mongoose.model('Slot', slotSchema);
const Booking = mongoose.model('Booking', bookingSchema);
const Contact = mongoose.model('Contact', contactSchema);

function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

function requireFields(body, fields) {
  const missing = fields.filter((field) => body[field] === undefined || body[field] === null || String(body[field]).trim() === '');
  if (missing.length) {
    const error = new Error(`Missing required field(s): ${missing.join(', ')}`);
    error.status = 400;
    throw error;
  }
}


async function seedAdminIfEmpty() {
  const admin = await User.findOne({ email: 'admin@parking.com' });
  if (!admin) {
    await User.create({
      role: 'Admin',
      fullName: 'Smart Parking Admin',
      email: 'admin@parking.com',
      phone: '9999999999',
      password: 'admin123',
      provider: 'local',
    });
    console.log('Demo admin inserted: admin@parking.com / admin123');
  }
}

async function seedSlotsIfEmpty() {
  const count = await Slot.countDocuments();
  if (count > 0) return;

  await Slot.insertMany([
    { slotNumber: 'A-01', floor: 'Ground Floor', vehicleType: 'Car', hourlyRate: 40, status: 'Available' },
    { slotNumber: 'A-02', floor: 'Ground Floor', vehicleType: 'Car', hourlyRate: 40, status: 'Available' },
    { slotNumber: 'B-01', floor: 'First Floor', vehicleType: 'Bike', hourlyRate: 20, status: 'Available' },
    { slotNumber: 'B-02', floor: 'First Floor', vehicleType: 'Bike', hourlyRate: 20, status: 'Available' },
    { slotNumber: 'EV-01', floor: 'Basement', vehicleType: 'EV', hourlyRate: 60, status: 'Available' },
  ]);
  console.log('Demo parking slots inserted');
}

app.get('/', (req, res) => {
  res.json({ message: 'Smart Parking Backend Running', database: mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected' });
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' });
});


app.post('/api/auth/register', asyncHandler(async (req, res) => {
  requireFields(req.body, ['role', 'fullName', 'email', 'phone', 'password']);
  const email = String(req.body.email).toLowerCase().trim();
  const exists = await User.findOne({ email });
  if (exists) return res.status(400).json({ message: 'This email is already registered. Login karein.' });
  if (String(req.body.password).length < 6) return res.status(400).json({ message: 'Password minimum 6 characters ka hona chahiye' });

  const user = await User.create({
    role: req.body.role,
    fullName: req.body.fullName,
    email,
    phone: req.body.phone,
    password: req.body.password,
    provider: 'local',
  });
  res.status(201).json({ message: 'Registration successful', user: { id: user._id, role: user.role, fullName: user.fullName, email: user.email, phone: user.phone } });
}));

app.post('/api/auth/login', asyncHandler(async (req, res) => {
  requireFields(req.body, ['email', 'password']);
  const email = String(req.body.email).toLowerCase().trim();
  const user = await User.findOne({ email });
  if (!user || user.password !== req.body.password) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }
  res.json({ message: 'Login successful', user: { id: user._id, role: user.role, fullName: user.fullName, email: user.email, phone: user.phone } });
}));

app.post('/api/auth/google', asyncHandler(async (req, res) => {
  requireFields(req.body, ['fullName', 'email']);
  const email = String(req.body.email).toLowerCase().trim();
  let user = await User.findOne({ email });
  if (!user) {
    user = await User.create({
      role: req.body.role || 'User',
      fullName: req.body.fullName,
      email,
      phone: req.body.phone || '',
      password: 'google-demo-login',
      provider: 'google-demo',
    });
  }
  res.json({ message: 'Google demo login successful', user: { id: user._id, role: user.role, fullName: user.fullName, email: user.email, phone: user.phone } });
}));

app.get('/api/users', asyncHandler(async (req, res) => {
  const users = await User.find().select('-password').sort({ createdAt: -1 });
  res.json(users);
}));

app.get('/api/slots', asyncHandler(async (req, res) => {
  const slots = await Slot.find().sort({ slotNumber: 1 });
  res.json(slots);
}));

app.post('/api/slots', asyncHandler(async (req, res) => {
  requireFields(req.body, ['slotNumber', 'floor', 'vehicleType', 'hourlyRate']);
  const slot = await Slot.create(req.body);
  res.status(201).json(slot);
}));

app.put('/api/slots/:id', asyncHandler(async (req, res) => {
  const slot = await Slot.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!slot) return res.status(404).json({ message: 'Slot not found' });
  res.json(slot);
}));

app.delete('/api/slots/:id', asyncHandler(async (req, res) => {
  const activeBooking = await Booking.findOne({ slot: req.params.id, status: 'Active' });
  if (activeBooking) return res.status(400).json({ message: 'Cannot delete slot with active booking' });
  const slot = await Slot.findByIdAndDelete(req.params.id);
  if (!slot) return res.status(404).json({ message: 'Slot not found' });
  res.json({ message: 'Slot deleted successfully' });
}));

app.get('/api/bookings', asyncHandler(async (req, res) => {
  const bookings = await Booking.find().populate('slot').sort({ createdAt: -1 });
  res.json(bookings);
}));

app.post('/api/bookings', asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'phone', 'vehicleNumber', 'vehicleType', 'slot', 'hours']);
  const slot = await Slot.findById(req.body.slot);
  if (!slot) return res.status(404).json({ message: 'Selected slot not found' });
  if (slot.status !== 'Available') return res.status(400).json({ message: 'This slot is not available' });
  if (slot.vehicleType !== req.body.vehicleType) return res.status(400).json({ message: `This slot is only for ${slot.vehicleType}` });

  const hours = Number(req.body.hours);
  const amount = hours * Number(slot.hourlyRate);
  const booking = await Booking.create({ ...req.body, hours, amount, status: 'Active' });
  slot.status = 'Booked';
  await slot.save();

  const savedBooking = await Booking.findById(booking._id).populate('slot');
  res.status(201).json(savedBooking);
}));

app.patch('/api/bookings/:id/complete', asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id).populate('slot');
  if (!booking) return res.status(404).json({ message: 'Booking not found' });
  booking.status = 'Completed';
  await booking.save();
  if (booking.slot) {
    await Slot.findByIdAndUpdate(booking.slot._id, { status: 'Available' });
  }
  res.json({ message: 'Booking completed', booking });
}));

app.delete('/api/bookings/:id', asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id).populate('slot');
  if (!booking) return res.status(404).json({ message: 'Booking not found' });
  if (booking.slot && booking.status === 'Active') {
    await Slot.findByIdAndUpdate(booking.slot._id, { status: 'Available' });
  }
  await Booking.findByIdAndDelete(req.params.id);
  res.json({ message: 'Booking deleted successfully' });
}));

app.get('/api/dashboard', asyncHandler(async (req, res) => {
  const [totalSlots, availableSlots, bookedSlots, activeBookings, completedBookings, revenue] = await Promise.all([
    Slot.countDocuments(),
    Slot.countDocuments({ status: 'Available' }),
    Slot.countDocuments({ status: 'Booked' }),
    Booking.countDocuments({ status: 'Active' }),
    Booking.countDocuments({ status: 'Completed' }),
    Booking.aggregate([{ $group: { _id: null, total: { $sum: '$amount' } } }]),
  ]);
  res.json({
    totalSlots,
    availableSlots,
    bookedSlots,
    activeBookings,
    completedBookings,
    revenue: revenue[0]?.total || 0,
  });
}));

app.post('/api/contact', asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'email', 'message']);
  const contact = await Contact.create(req.body);
  res.status(201).json({ message: 'Message saved successfully', contact });
}));

app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
});

mongoose
  .connect(MONGO_URI)
  .then(async () => {
    console.log('MongoDB Connected:', MONGO_URI);
    await seedAdminIfEmpty();
    await seedSlotsIfEmpty();
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('MongoDB connection failed:', err.message);
    console.error('Start MongoDB first or check MONGO_URI in backend/.env');
    process.exit(1);
  });
