import { useEffect, useMemo, useState } from 'react';
import api from '../api';

const initialForm = { name: '', phone: '', vehicleNumber: '', vehicleType: 'Car', slot: '', hours: 1 };

export default function Booking() {
  const [slots, setSlots] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const selectedSlot = useMemo(() => slots.find((slot) => slot._id === form.slot), [slots, form.slot]);
  const total = selectedSlot ? Number(selectedSlot.hourlyRate) * Number(form.hours || 1) : 0;

  async function loadSlots() {
    const res = await api.get('/slots');
    setSlots(res.data);
  }

  useEffect(() => {
    loadSlots().catch(() => setError('Backend connect nahi ho raha. Pehle backend aur MongoDB start karein.'));
  }, []);

  function updateField(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function submitBooking(e) {
    e.preventDefault();
    setMessage('');
    setError('');
    if (!form.name || !form.phone || !form.vehicleNumber || !form.vehicleType || !form.slot || !form.hours) {
      setError('Please fill all fields. Koi bhi field blank nahi honi chahiye.');
      return;
    }
    try {
      const res = await api.post('/bookings', form);
      setMessage(`Booking successful! Slot ${res.data.slot.slotNumber}, Amount ₹${res.data.amount}`);
      setForm(initialForm);
      loadSlots();
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed');
    }
  }

  return (
    <main className="container">
      <h1 className="section-title">Book Parking Slot</h1>
      {message && <div className="alert">{message}</div>}
      {error && <div className="alert error">{error}</div>}
      <div className="card">
        <form className="form" onSubmit={submitBooking}>
          <div className="form-grid">
            <div><label>Name</label><input name="name" value={form.name} onChange={updateField} placeholder="Enter name" /></div>
            <div><label>Phone</label><input name="phone" value={form.phone} onChange={updateField} placeholder="Enter phone" /></div>
            <div><label>Vehicle Number</label><input name="vehicleNumber" value={form.vehicleNumber} onChange={updateField} placeholder="MP04AB1234" /></div>
            <div><label>Vehicle Type</label><select name="vehicleType" value={form.vehicleType} onChange={updateField}><option>Car</option><option>Bike</option><option>EV</option></select></div>
            <div><label>Available Slot</label><select name="slot" value={form.slot} onChange={updateField}><option value="">Select slot</option>{slots.filter((s) => s.status === 'Available' && s.vehicleType === form.vehicleType).map((slot) => <option key={slot._id} value={slot._id}>{slot.slotNumber} - {slot.floor} - ₹{slot.hourlyRate}/hr</option>)}</select></div>
            <div><label>Hours</label><input name="hours" type="number" min="1" value={form.hours} onChange={updateField} /></div>
          </div>
          <h3>Total Amount: ₹{total}</h3>
          <button className="btn" type="submit">Confirm Booking</button>
        </form>
      </div>
    </main>
  );
}
