SMART PARKING FULLSTACK - FIXED WITH LOGIN & REGISTRATION

NEW FEATURES ADDED:
1. Premium Login page created.
2. Premium Registration page created.
3. Registration has role select: User, Admin, Staff.
4. Registration has OTP demo option.
5. Registration has Google signup demo option.
6. Login has Google login demo option.
7. Login/Register data saves in MongoDB users collection.
8. Demo admin inserted automatically:
   Email: admin@parking.com
   Password: admin123

HOW TO RUN:

STEP 1: Extract ZIP.

STEP 2: Start MongoDB.
If MongoDB is installed, open one terminal and run:
mongod

STEP 3: Run backend.
cd backend
npm install
npm start

Backend URL:
http://localhost:5000

STEP 4: Run frontend in a new terminal.
cd frontend
npm install
npm run dev

Frontend URL:
http://localhost:5173/#/

Open login page:
http://localhost:5173/#/login

Open registration page:
http://localhost:5173/#/register

NOTE:
- Do not open index.html directly.
- Backend, frontend and MongoDB must run together.
- Google login is demo mode. Real Google OAuth requires Google Cloud Client ID setup.
